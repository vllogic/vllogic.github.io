---
name: VLLINK 目标电源跌落与恢复
description: 通过 VLLINK/CMSIS-DAP 调试器，用 WebUSB 发送 DAP_PowerCycle (0x0F) 让目标板的 VREF / VOUT 5V 跌落再恢复，实现无人值守的硬复位。当目标无响应、调试口被锁死、nRESET 无法恢复，或自动化测试需要强制重新上电时使用。
---

# 用 VLLINK 给目标板重新上电（DAP_PowerCycle）

强制把目标板的电源拉低再恢复，让死机或调试口锁死的目标在无人干预的情况下恢复。

本技能**只走 WebUSB**（接口 1，vendor request `0x10`/`0x11`）。不要用 HID，也不要用 bulk 接口 0。

## 何时使用

- 目标固件跑飞、SWD/JTAG 被锁，`DAP_ResetTarget` 和 nRESET 都无效；
- CI / 自动化流程需要无人值守的硬复位；
- 需要确认目标**真的掉过电**（而不只是被按在复位里）。

**不要**用它做普通软复位。优先尝试 `DAP_ResetTarget`(0x0A) 或 `DAP_SWJ_Pins`(0x10 的 nRESET)。

## 核心模型（动手前必读）

每个通道有两层独立状态：

| 层 | 含义 | 谁改变它 |
| --- | --- | --- |
| `ConfigState` | 通道**是否被配置为启用** | 设备配置（`Vout=enable`、`Vref_Voltage_mV`）或板载 UI |
| 强制跌落（`down`） | 通道被临时拉低 | `DAP_PowerCycle` 的 **Off** / **On** |
| `PowerState` | 实际在输出的通道 | `ConfigState & ~down` |

由此必须遵守：

1. `On` **只释放**被强制跌落的通道，**绝不会**给未配置的通道上电。因此命令可能返回成功
   （`Status=0x00`）但实际什么都没打开。
2. `ConfigState=0x00` 表示命令是**空操作**。此时应先修配置，不要重试命令。
3. `ConfigState ^ PowerState` = 当前被强制跌落的通道。
4. 固件**不会自动恢复**。如果只发了 **Off** 没发 **On**，目标会一直断电。
   必须成对使用，并在所有错误路径上补发 **On**。

## 协议

命令 `0x0F`，请求 3 字节，响应 4 字节：

```
请求: [0x0F, Channel, Action]
响应: [0x0F, Status, ConfigState, PowerState]
```

`Channel`（位掩码）：

| 值 | 含义 |
| --- | --- |
| `0x00` | 无动作，仅查询状态（`Action` 被忽略） |
| `0x01` | VREF 输出 |
| `0x02` | VOUT 5V 输出 |
| `0x03` | 两者 |
| `0xFF` | 广播到所有已实现通道 |

`Action`：`0x00` = Off（跌落），`0x01` = On（释放）。其它值被忽略。

`Status`：`0x00` = DAP_OK，`0xFF` = 错误。

未实现的通道位会被忽略（不报错）。该命令**不要求** `DAP_Connect`，调试端口断开时也能用。

## 步骤 0 — 校验能力（每个会话一次）

读 `DAP_Info` 的 ID `0xF0`，检查 **Info1 的 bit7**：

```
请求: [0x00, 0xF0]
响应: [0x00, Len, Info0, Info1, ...]
```

`Len >= 2` 且 `(Info1 & 0x80) != 0` 表示支持 `DAP_PowerCycle`。
若该位为 0，立即停止，并报告该调试器不支持此功能。

然后用 `[0x0F, 0x00, 0x01]` 查询状态，检查 `ConfigState`：

- `ConfigState == 0` → 目标电源未配置。停止，并告知用户去设备配置里启用
  （`Vout=enable`、`Vref_Voltage_mV=3300`）。
- 否则记录初始的 `PowerState`，以便结束后恢复到原状态。

## 步骤 1 — 执行电源循环（默认配方）

```
1. DAP_Disconnect                    # [0x03] 结束调试会话
2. DAP_PowerCycle(0x03, Off)         # [0x0F, 0x03, 0x00] 拉低 VREF + VOUT
3. 等待 >= 200 ms                    # 放电 / 电压跌落
4. DAP_PowerCycle(0x03, On)          # [0x0F, 0x03, 0x01] 释放
5. 等待 >= 200 ms                    # 电源稳定、上电复位释放
6. DAP_Connect(SWD 或 JTAG)          # [0x02, 0x01] / [0x02, 0x02]
```

注意事项：

- 如果传输层支持，优先用 `DAP_ExecuteCommands`(0x7F) 把整段打包成一次事务，
  避免时序受主机/USB 往返延迟影响。
- `DAP_Delay`(0x09) 的参数是 **16 位微秒**，单次最大约 65.5 ms。
  需要更久就发多条，或在主机侧等待。
- 只跌落单路时用 `Channel=0x01`（VREF）或 `0x02`（VOUT）。
  不要假设关掉一路会连带关掉另一路。
- **Off 和 On 要用相同的通道掩码**。只有当所有已实现通道都已配置时，
  Off 用 `0x03`、On 用 `0xFF` 才安全；否则可能释放了从未跌落的通道。

## 步骤 2 — 验证结果

**Off** 之后查询，要求对应位已从 `PowerState` 消失。
**On** 之后查询，要求对应位已恢复：

```
cfg = response[2]; pwr = response[3]
down = cfg & ~pwr                    # 当前被跌落的通道
```

以下情况一律视为失败并上报，不要静默继续：

- `Status != 0x00`
- Off 之后：`(pwr & mask) != 0`（电源仍在上）
- On 之后：`(pwr & mask) != (cfg & mask)`（电源没恢复）
- 循环过程中 `ConfigState` 发生变化（配置被修改或被复位）

## 失败处理

除非用户明确要求保持断电，否则任何情况下都要让目标恢复供电：

```
try   { Off; 等待; On; 等待; }
catch { On; }        # 尽力补发恢复，然后重新抛出异常
```

如果 `On` 失败，重试一次；仍失败则报告"仍处于跌落的通道掩码"和原始响应字节。
**绝不**无限循环 Off/On。

## 传输层（WebUSB，接口 1）

与 console 的 `dapExecute()` 保持一致：

1. `controlTransferOut({ requestType:'vendor', recipient:'interface',
   request:0x10, value:0, index:iface }, payload)`
2. 轮询 `controlTransferIn({ ..., request:0x11 }, 2)`，直到读到的小端 int16 `> 0`
   （预算约 200 ms，步进 2 ms）
3. `controlTransferIn({ ..., request:0x10 }, 512)` 取回响应

设备有多个接口。要认领 `interfaceClass == 0xFF` 且 `interfaceSubClass == 0x03`
的那个（WebUSB CMSIS-DAP），通常是接口 1。不要打开 HID（接口 4）或 bulk 接口 0。

Linux 主机用 pyusb 时，等价写法：

```python
dev.ctrl_transfer(0x41, 0x10, 0, iface, bytes(payload))
# 轮询 (0xC1, 0x11, 0, iface, 2) 直到 int16 > 0
resp = bytes(dev.ctrl_transfer(0xC1, 0x10, 0, iface, 512))
```

`set_configuration()` 通常会因 CDC/HID 已被内核驱动占用而报 `Resource busy`；
跳过它，直接在已配置的设备上操作即可。

## 硬性规则

- 没有配对的 **On**，绝不单独发 **Off**（除非用户明确要求保持断电）。
- 绝不假设 `On` 已经生效，必须回读 `PowerState`。
- 绝不把 `Status=0x00` 单独当作成功。
- 若 `ConfigState == 0`，立即停止：这是"未配置"，不是"坏了"。
- 任何异常都要回报原始 4 字节响应。
