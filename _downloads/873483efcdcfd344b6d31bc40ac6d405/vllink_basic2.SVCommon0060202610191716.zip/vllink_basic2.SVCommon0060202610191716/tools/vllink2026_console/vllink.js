/**
 * Vllink 硬件通讯管理类 (WebUSB)
 * 适配固件版本 >= V00.40
 */
class VllinkManager {
    constructor() {
        this.device = null;
        this.interfaceNum = 0;
        this.filters = [
            { vendorId: 0x1209, productId: 0x6666 }, 
            { vendorId: 0x0d28, productId: 0x0204 }
        ];
        this.isBusy = false; // 通讯排队锁
        this.powerCapable = false; // DAP_PowerCycle (0x0F) 支持标志
        this.powerState = null;    // { status, config, power }
    }

    /**
     * 连接设备并独占接口
     * @param {USBDevice} existingDevice - 预期的设备实例
     * @param {boolean} forceRequest - 是否强制弹出浏览器设备选择框
     */
    async connect(existingDevice = null, forceRequest = false) {
        if (existingDevice) {
            // 场景 1: 原生 connect 事件触发的自动重连
            this.device = existingDevice;
        } else if (forceRequest) {
            // 场景 2: 用户主动点击了断开后，要求强制弹窗重新选择
            this.device = await navigator.usb.requestDevice({ filters: this.filters });
        } else {
            // 场景 3: 常规点击或刷新开屏，尝试静默获取
            const authorizedDevices = await navigator.usb.getDevices();
            const matchedDevices = authorizedDevices.filter(d => 
                this.filters.some(f => f.vendorId === d.vendorId && f.productId === d.productId)
            );

            if (matchedDevices.length > 0) {
                // 【新特性】：优先寻找最后一次成功连接的设备 (通过 serialNumber 匹配)
                const lastSn = localStorage.getItem('vllink-last-sn');
                let target = matchedDevices.find(d => d.serialNumber && d.serialNumber === lastSn);
                
                // 如果没找到匹配 SN 的，默认连第一个
                if (!target) target = matchedDevices[0];
                this.device = target;
            } else {
                // 完全没授权过，只能弹窗
                this.device = await navigator.usb.requestDevice({ filters: this.filters });
            }
        }

        await this.device.open();
        
        const iface = this.device.configuration.interfaces.find(i => 
            i.alternate.interfaceClass === 0xFF && i.alternate.interfaceSubclass === 0x03
        );
        if (!iface) throw new Error("Vllink WebUSB Interface not found");
        
        this.interfaceNum = iface.interfaceNumber;
        await this.device.claimInterface(this.interfaceNum);

        // 【新特性】：连接成功后，持久化记录当前设备的唯一序列号
        if (this.device.serialNumber) {
            localStorage.setItem('vllink-last-sn', this.device.serialNumber);
        }

        return this.device;
    }

    async disconnect() {
        this.isBusy = true;
        if (this.device && this.device.opened) {
            try {
                await this.device.releaseInterface(this.interfaceNum);
                await this.device.close();
            } catch (e) { console.warn("Release warning:", e); }
        }
        this.device = null;
        this.isBusy = false;
    }

    async queryInfo() {
        if (!this.device || this.isBusy) return null;
        try {
            const result = await this.device.controlTransferIn({
                requestType: 'vendor', recipient: 'interface',
                request: 0x00, value: 0x00, index: this.interfaceNum
            }, 512);
            if (result.status === 'ok') return this.parseInfo(result.data.buffer);
        } catch (e) {
            if (e.name === 'NetworkError' || e.name === 'NotFoundError' || e.message.includes('disconnected')) {
                throw e;
            }
            return null;
        }
        return null;
    }

    async selectDebugger(idx) {
        if (!this.device) return;
        await this.device.controlTransferOut({
            requestType: 'vendor', recipient: 'interface',
            request: 0x00, value: idx & 0xFF, index: this.interfaceNum
        });
    }

    async dapExecute(payload) {
        if (!this.device) throw new Error("Device disconnected");
        
        await this.device.controlTransferOut({
            requestType: 'vendor', recipient: 'interface',
            request: 0x10, value: 0, index: this.interfaceNum
        }, payload);

        let ready = false;
        for (let i = 0; i < 100; i++) {
            await new Promise(r => setTimeout(r, 2)); 
            const res = await this.device.controlTransferIn({
                requestType: 'vendor', recipient: 'interface',
                request: 0x11, value: 0, index: this.interfaceNum
            }, 2);
            if (res.data.getInt16(0, true) > 0) { ready = true; break; }
        }
        if (!ready) throw new Error("DAP Communication Timeout");

        const resp = await this.device.controlTransferIn({
            requestType: 'vendor', recipient: 'interface',
            request: 0x10, value: 0, index: this.interfaceNum
        }, 512);
        return new Uint8Array(resp.data.buffer);
    }

    /**
     * 查询 DAP_PowerCycle (0x0F) 能力：DAP_Info(0xF0) 的 Info1 bit7
     */
    async queryPowerCapability() {
        try {
            const resp = await this.dapExecute(new Uint8Array([0x00, 0xF0]));
            if (resp[0] !== 0x00 || resp[1] < 2) return false;
            return (resp[3] & 0x80) !== 0;
        } catch (e) {
            return false;
        }
    }

    /**
     * 查询电源状态（Channel=0x00 仅回读，不产生动作）
     * @returns {{status:number, config:number, power:number}|null}
     */
    async queryPowerState() {
        try {
            const resp = await this.dapExecute(new Uint8Array([0x0F, 0x00, 0x01]));
            if (resp[0] !== 0x0F) return null;
            return { status: resp[1], config: resp[2], power: resp[3] };
        } catch (e) {
            return null;
        }
    }

    /**
     * 强制所选通道跌落 / 恢复
     * @param {number} channelMask - bit0=VREF, bit1=VOUT_5V, 0xFF=全部
     * @param {boolean} down - true=跌落(Off), false=恢复(On)
     */
    async setPowerDown(channelMask, down) {
        const resp = await this.dapExecute(new Uint8Array([0x0F, channelMask & 0xFF, down ? 0x00 : 0x01]));
        if (resp[0] !== 0x0F) return null;
        return { status: resp[1], config: resp[2], power: resp[3] };
    }

    async getConfigInfo() {
        const pkg = new Uint8Array([0x91, 0x01]); 
        const resp = await this.dapExecute(pkg);
        const view = new DataView(resp.buffer);
        if (resp[2] !== 0 || resp[3] !== 0) throw new Error("Get Info Failed");

        const info = {
            version: view.getUint32(4, true).toString(16),
            size: view.getUint32(8, true),
            fileLimit: view.getUint32(12, true),
            fileLengths: [] 
        };
        for (let i = 0; i < 8; i++) {
            info.fileLengths.push(view.getUint16(16 + (i * 2), true));
        }
        return info;
    }

    async resetDevice() {
        const pkg = new Uint8Array([0x91, 0x02]);
        const resp = await this.dapExecute(pkg);
        return resp[2] === 0 && resp[3] === 0;
    }

    async readConfig(totalSize) {
        let offset = 0;
        let completeData = new Uint8Array(0);
        const decoder = new TextDecoder();
        while (offset < totalSize) {
            const len = Math.min(256, totalSize - offset); 
            const pkg = new Uint8Array(18); 
            pkg[0] = 0x91; pkg[1] = 0x10; 
            const view = new DataView(pkg.buffer);
            view.setUint32(2, 0, true);
            view.setUint32(6, totalSize, true);
            view.setUint32(10, offset, true);
            view.setUint32(14, len, true);
            
            const resp = await this.dapExecute(pkg);
            if (resp[3] !== 0) break;
            
            const chunkLen = new DataView(resp.buffer).getUint32(4, true);
            const chunkData = resp.slice(8, 8 + chunkLen);
            const tmp = new Uint8Array(completeData.length + chunkData.length);
            tmp.set(completeData); tmp.set(chunkData, completeData.length);
            completeData = tmp;
            offset += chunkLen;
        }
        return decoder.decode(completeData).replace(/\0/g, '');
    }

    async writeConfig(text, totalSize) {
        const encoder = new TextEncoder();
        const rawBytes = encoder.encode(text);
        
        const fullPayload = new Uint8Array(totalSize);
        fullPayload.set(rawBytes.slice(0, totalSize));
        
        let offset = 0;
        while (offset < totalSize) {
            const len = Math.min(256, totalSize - offset);
            const pkg = new Uint8Array(18 + len);
            pkg[0] = 0x91; pkg[1] = 0x20; 
            const view = new DataView(pkg.buffer);
            view.setUint32(2, 0, true);
            view.setUint32(6, totalSize, true);
            view.setUint32(10, offset, true);
            view.setUint32(14, len, true);
            pkg.set(fullPayload.slice(offset, offset + len), 18);
            
            const resp = await this.dapExecute(pkg);
            if (resp[3] !== 0) throw new Error("Write Error");
            offset += len;
        }
    }

    async writeFileChunk(idx, fullLength, pos, data256) {
        const pkg = new Uint8Array(18 + 256);
        pkg[0] = 0x91; pkg[1] = 0x21;
        const view = new DataView(pkg.buffer);
        view.setUint32(2, idx, true);
        view.setUint32(6, fullLength, true);
        view.setUint32(10, pos, true);
        view.setUint32(14, 256, true);
        pkg.set(data256, 18);
        
        const resp = await this.dapExecute(pkg);
        if (resp[3] !== 0) throw new Error(`Write failed @ 0x${pos.toString(16)} (Err: ${resp[3]})`);
    }

    async readFileChunk(idx, fullLength, pos) {
        const pkg = new Uint8Array(18);
        pkg[0] = 0x91; pkg[1] = 0x11;
        const view = new DataView(pkg.buffer);
        view.setUint32(2, idx, true);
        view.setUint32(6, fullLength, true);
        view.setUint32(10, pos, true);
        view.setUint32(14, 256, true);
        
        const resp = await this.dapExecute(pkg);
        if (resp[3] !== 0) throw new Error(`Read failed @ 0x${pos.toString(16)}`);
        
        const len = new DataView(resp.buffer).getUint32(4, true);
        return resp.slice(8, 8 + len);
    }

    parseInfo(buffer) {
        const view = new DataView(buffer);
        const decoder = new TextDecoder();
        const info = { select_idx: view.getUint8(0), local: null, remote: [] };
        
        const parseNode = (offset) => {
            const macRaw = new Uint8Array(buffer, offset + 16, 6);
            const macStr = Array.from(macRaw).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(':');
            const aliasRaw = new Uint8Array(buffer, offset + 22, 26);
            let aliasStr = decoder.decode(aliasRaw).replace(/\0/g, '').trim();
            return { us: view.getBigUint64(offset, true), delay_us: view.getUint32(offset + 8, true), mac: macStr, alias: aliasStr || "Unnamed" };
        };
        
        info.local = parseNode(32);
        for (let i = 0; i < 9; i++) {
            const offset = 32 + 48 + (i * 48);
            const node = parseNode(offset);
            if (node.us > 0n) info.remote.push({ ...node, id: i + 1 });
        }
        return info;
    }
}