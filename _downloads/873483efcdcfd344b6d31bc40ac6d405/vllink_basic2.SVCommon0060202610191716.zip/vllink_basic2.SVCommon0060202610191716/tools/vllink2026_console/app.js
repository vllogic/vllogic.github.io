/**
 * 三模态主题管理器
 */
const ThemeManager = {
    btns: document.querySelectorAll('[data-theme]'),
    slider: document.getElementById('themeSlider'),
    init() {
        const saved = localStorage.getItem('vllink-theme-preference') || 'auto';
        this.apply(saved);
        this.btns.forEach(btn => btn.addEventListener('click', () => this.apply(btn.dataset.theme)));
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
            if (localStorage.getItem('vllink-theme-preference') === 'auto') this.apply('auto');
        });
    },
    apply(mode) {
        localStorage.setItem('vllink-theme-preference', mode);
        const isDark = mode === 'auto' ? window.matchMedia('(prefers-color-scheme: dark)').matches : mode === 'dark';
        document.documentElement.classList.toggle('dark', isDark);
        const activeIdx = Array.from(this.btns).findIndex(b => b.dataset.theme === mode);
        if (this.slider) this.slider.style.left = `calc(${activeIdx * 33.33}% + 4px)`;
        this.btns.forEach(btn => {
            const isActive = btn.dataset.theme === mode;
            btn.classList.toggle('text-white', isActive);
            btn.classList.toggle('text-slate-500', !isActive);
        });
    }
};

/**
 * 选项页切换管理
 */
const TabManager = {
    btns: { config: document.getElementById('tab-btn-config'), data: document.getElementById('tab-btn-tbd') },
    contents: { config: document.getElementById('tab-content-config'), data: document.getElementById('tab-content-tbd') },
    init() {
        this.btns.config.onclick = () => this.switch('config');
        this.btns.data.onclick = () => { this.switch('data'); DataManager.load(); };
    },
    switch(target) {
        Object.keys(this.btns).forEach(key => {
            const active = key === target;
            this.btns[key].classList.toggle('tab-active', active);
            this.btns[key].classList.toggle('text-slate-400', !active);
            this.contents[key].classList.toggle('hidden', !active);
        });
    }
};

/**
 * 数据区块管理模块
 */
const DataManager = {
    container: document.getElementById('tab-content-tbd'),
    activeBuffers: {}, 

    async load() {
        if (!vllink.device) return; 
        this.container.innerHTML = `<div class="p-20 text-center animate-pulse text-slate-500 italic text-sm font-mono">Loading data segments...</div>`;
        vllink.isBusy = true;
        try {
            const info = await vllink.getConfigInfo();
            this.render(info);
        } catch (e) {
            this.container.innerHTML = `<div class="p-20 text-red-500 text-center font-mono">Failed: ${e.message}</div>`;
        } finally {
            vllink.isBusy = false;
        }
    },

    render(info) {
        let html = `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">`;
        let blocksFound = 0;

        for (let i = 0; i < info.fileLimit; i++) {
            const kb = info.fileLengths[i];
            if (kb > 0) {
                blocksFound++;
                const hasData = !!this.activeBuffers[i];
                html += `
                <div class="glass border border-slate-200 dark:border-slate-800 rounded-3xl p-6 flex flex-col gap-5 shadow-xl transition-all relative overflow-hidden">
                    <div class="flex justify-between items-center relative z-10">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-500 font-black text-xs border border-slate-200/50 dark:border-white/10">${i}</div>
                            <h3 class="font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter">Data Block ${i}</h3>
                        </div>
                        <span class="text-[10px] font-mono bg-slate-100 dark:bg-white/5 px-2 py-1 rounded text-slate-500">MAX: ${kb} KB</span>
                    </div>

                    <div id="data-ui-${i}" class="space-y-3 bg-slate-50 dark:bg-black/20 p-4 rounded-2xl border border-slate-100 dark:border-white/5 relative z-10">
                        <div class="flex justify-between items-center">
                            <span id="data-status-text-${i}" class="text-[10px] font-black uppercase tracking-widest text-slate-400 transition-colors">准备就绪</span>
                            <span id="data-percent-${i}" class="text-[10px] font-mono text-slate-400">0%</span>
                        </div>
                        <div class="h-1.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div id="data-bar-${i}" class="h-full bg-primary transition-all duration-300 w-0" style="box-shadow: 0 0 10px rgba(0, 212, 255, 0.3)"></div>
                        </div>
                        <div class="flex justify-end">
                            <span id="data-speed-box-${i}" class="text-[9px] text-slate-400 font-mono opacity-60 italic transition-opacity">Speed: 0.0 KB/s</span>
                        </div>
                    </div>

                    <div class="flex gap-3 relative z-10">
                        <button onclick="DataManager.pickFile(${i}, ${kb})" id="btn-load-${i}" class="flex-1 py-3 bg-primary text-white rounded-xl font-black text-xs hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-primary/20">载入并写入</button>
                        <button onclick="DataManager.verify(${i})" id="btn-verify-${i}" ${hasData ? '' : 'disabled'} class="flex-1 py-3 border-2 border-primary/30 text-primary rounded-xl font-black text-xs hover:bg-primary/5 active:scale-95 transition-all disabled:opacity-30 disabled:grayscale disabled:pointer-events-none">回读校验</button>
                    </div>
                    <input type="file" id="input-file-${i}" class="hidden" onchange="DataManager.handlePick(${i}, ${kb})">
                </div>`;
            }
        }
        this.container.innerHTML = blocksFound > 0 ? html + `</div>` : `<div class="p-20 text-center italic text-slate-500">设备未定义数据区块</div>`;
    },

    pickFile(idx) { document.getElementById(`input-file-${idx}`).click(); },

    async handlePick(idx, maxKb) {
        const input = document.getElementById(`input-file-${idx}`);
        if (!input.files.length) return;
        const file = input.files[0];
        
        if (file.size > maxKb * 1024) {
            this.showFeedback(idx, `文件超限 (MAX ${maxKb}KB)`, 'fail');
            input.value = ''; return;
        }

        const rawBuffer = await file.arrayBuffer();
        const alignedLen = Math.ceil(rawBuffer.byteLength / 256) * 256;
        const paddedData = new Uint8Array(alignedLen).fill(0xff);
        paddedData.set(new Uint8Array(rawBuffer));
        
        this.activeBuffers[idx] = paddedData;
        await this.executeTransfer(idx, 'WRITE', paddedData);
    },

    showFeedback(idx, message, type) {
        const statusText = document.getElementById(`data-status-text-${idx}`);
        const bar = document.getElementById(`data-bar-${idx}`);
        const speedBox = document.getElementById(`data-speed-box-${idx}`);
        if(!statusText || !bar || !speedBox) return;

        statusText.innerText = message.toUpperCase();
        statusText.classList.remove('text-primary', 'text-emerald-500', 'text-rose-500', 'animate-pulse');
        bar.classList.remove('bg-primary', 'bg-emerald-500', 'bg-rose-500');

        if (type === 'success') {
            statusText.classList.add('text-emerald-500');
            bar.classList.add('bg-emerald-500');
            bar.style.boxShadow = "0 0 15px rgba(16, 185, 129, 0.5)";
            speedBox.classList.add('opacity-0');
        } else if (type === 'fail') {
            statusText.classList.add('text-rose-500');
            bar.classList.add('bg-rose-500');
            bar.style.boxShadow = "0 0 15px rgba(244, 63, 94, 0.5)";
            speedBox.classList.remove('opacity-0');
        } else {
            statusText.classList.add('text-primary', 'animate-pulse');
            bar.classList.add('bg-primary');
            bar.style.boxShadow = "0 0 10px rgba(0, 212, 255, 0.3)";
            speedBox.classList.remove('opacity-0');
        }
    },

    async executeTransfer(idx, mode, data) {
        const isWrite = mode === 'WRITE';
        const bar = document.getElementById(`data-bar-${idx}`);
        const percentTxt = document.getElementById(`data-percent-${idx}`);
        const speedTxt = document.getElementById(`data-speed-box-${idx}`);
        const btnLoad = document.getElementById(`btn-load-${idx}`);
        const btnVerify = document.getElementById(`btn-verify-${idx}`);

        this.showFeedback(idx, isWrite ? '写入中...' : '校验中...', 'work');
        vllink.isBusy = true;
        btnLoad.disabled = true;
        btnVerify.disabled = true;
        
        const startTime = Date.now();

        try {
            for (let pos = 0; pos < data.length; pos += 256) {
                const chunk = data.slice(pos, pos + 256);
                if (isWrite) {
                    await vllink.writeFileChunk(idx, data.length, pos, chunk);
                } else {
                    const hardwareChunk = await vllink.readFileChunk(idx, data.length, pos);
                    if (chunk.some((val, j) => val !== hardwareChunk[j])) throw new Error(`数据不一致 @ 0x${pos.toString(16)}`);
                }

                const totalDone = pos + 256;
                const elapsed = (Date.now() - startTime) / 1000;
                const speed = (totalDone / 1024 / (elapsed || 0.001)).toFixed(1);
                const percent = Math.round((totalDone / data.length) * 100);

                bar.style.width = `${percent}%`;
                percentTxt.innerText = `${percent}%`;
                speedTxt.innerText = `Speed: ${speed} KB/s`;
            }
            this.showFeedback(idx, isWrite ? '写入成功 ✓' : '校验通过 ✓', 'success');
        } catch (e) {
            this.showFeedback(idx, e.message, 'fail');
        } finally {
            vllink.isBusy = false;
            btnLoad.disabled = false;
            if (this.activeBuffers[idx]) btnVerify.disabled = false;
        }
    },

    async verify(idx) {
        if (!this.activeBuffers[idx]) return;
        await this.executeTransfer(idx, 'VERIFY', this.activeBuffers[idx]);
    }
};

/**
 * 配置编辑器模块
 */
const ConfigEditor = {
    container: document.getElementById('tab-content-config'),
    editor: null, gutter: null, highlightLayer: null,
    originalLines: [], syncResults: [], isBusy: false, lastSelectedIdx: -1,

    init() { this.container.addEventListener('mouseleave', () => this.sync()); },

    updateStatus(type) {
        const dot = document.getElementById('editor-status-dot');
        const text = document.getElementById('editor-status-text');
        if (!dot || !text) return;
        const states = {
            synced: { color: 'bg-emerald-500', label: '已同步' },
            modified: { color: 'bg-amber-500', label: '待同步 (CTRL + Enter)' },
            syncing: { color: 'bg-primary animate-pulse', label: '通讯中...' },
            error: { color: 'bg-rose-500', label: '错误' }
        };
        const s = states[type];
        dot.className = `w-2 h-2 rounded-full transition-colors ${s.color}`;
        text.innerText = s.label;
    },

    async load(manager) {
        if (this.isBusy || !manager.device) return;
        this.isBusy = true; this.lockUI(true); manager.isBusy = true;
        try {
            this.container.innerHTML = `<div class="p-20 text-center animate-pulse text-slate-500 italic text-sm font-mono">Loading config...</div>`;
            const info = await manager.getConfigInfo();
            const text = await manager.readConfig(info.size);
            this.render(text);
            this.updateStatus('synced');
        } catch (e) {
            this.container.innerHTML = `<div class="p-20 text-red-500 text-center font-mono">Load Failed: ${e.message}</div>`;
        } finally { this.isBusy = false; manager.isBusy = false; this.lockUI(false); }
    },

    render(text) {
        const rows = text.replace(/\r/g, '').split('\n').filter(line => !line.trim().startsWith('Config_Password='));
        this.originalLines = [...rows];
        this.syncResults = new Array(rows.length).fill('none');

        this.container.innerHTML = `
            <div class="flex items-center justify-between mb-3 px-1">
                <div class="flex items-center gap-3">
                    <div id="editor-status-dot" class="w-2 h-2 rounded-full"></div>
                    <span id="editor-status-text" class="text-[10px] font-black uppercase tracking-widest text-slate-400"></span>
                </div>
                <div class="text-[9px] text-slate-400 font-mono opacity-60 italic">CTRL + ENTER TO SYNC</div>
            </div>
            <div class="relative flex font-mono text-sm bg-white dark:bg-slate-900/40 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-xl min-h-[300px]">
                <div id="vllink-highlights" class="absolute left-12 right-0 top-4 bottom-4 pointer-events-none leading-6"></div>
                <div id="vllink-gutter" class="w-12 py-4 bg-slate-50 dark:bg-slate-800/30 text-right pr-3 text-slate-400 select-none border-r border-slate-200 dark:border-slate-800/50 leading-6 z-10"></div>
                <div id="vllink-editor" contenteditable="true" spellcheck="false" class="flex-1 py-4 px-4 outline-none text-slate-700 dark:text-slate-200 leading-6 overflow-x-auto whitespace-pre z-20 bg-transparent"></div>
            </div>`;
        this.editor = document.getElementById('vllink-editor');
        this.gutter = document.getElementById('vllink-gutter');
        this.highlightLayer = document.getElementById('vllink-highlights');
        
        this.editor.innerText = rows.join('\n');
        this.refreshUI();

        this.editor.onscroll = () => {
            this.gutter.scrollTop = this.editor.scrollTop;
            this.highlightLayer.style.transform = `translateY(-${this.editor.scrollTop}px)`;
        };
        this.editor.oninput = () => { this.syncResults = []; this.refreshUI(); this.updateStatus('modified'); };
        this.editor.onkeydown = (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); this.sync(); } };
        this.editor.onpaste = (e) => { e.preventDefault(); document.execCommand("insertText", false, (e.originalEvent || e).clipboardData.getData('text/plain')); };
    },

    refreshUI() {
        const lines = this.editor.innerText.split('\n');
        let gutterHTML = '', highlightHTML = '';
        lines.forEach((text, i) => {
            gutterHTML += `<div>${i + 1}</div>`;
            let bgColor = 'transparent';
            const result = this.syncResults[i] || 'none';
            if (result === 'success') bgColor = 'rgba(16, 185, 129, 0.2)';
            else if (result === 'fail') bgColor = 'rgba(244, 63, 94, 0.2)';
            else if (text !== this.originalLines[i]) bgColor = 'rgba(245, 158, 11, 0.1)';
            highlightHTML += `<div style="height: 1.5rem; background: ${bgColor}; width: 100%;"></div>`;
        });
        this.gutter.innerHTML = gutterHTML;
        this.highlightLayer.innerHTML = highlightHTML;
    },

    async sync() {
        if (!this.editor || this.isBusy) return;
        const userInputText = this.editor.innerText;
        const userInputLines = userInputText.split('\n');
        if (userInputText === this.originalLines.join('\n')) return this.updateStatus('synced');
        
        this.updateStatus('syncing'); 
        this.isBusy = true; 
        this.lockUI(true); 
        vllink.isBusy = true;

        try {
            const info = await vllink.getConfigInfo();
            await vllink.writeConfig(userInputText, info.size);
            const verifyText = await vllink.readConfig(info.size);
            const verifyRows = verifyText.replace(/\r/g, '').split('\n').filter(line => !line.trim().startsWith('Config_Password='));
            
            this.syncResults = verifyRows.map((real, i) => {
                const typed = (userInputLines[i] || "").trim();
                return typed !== (this.originalLines[i] || "").trim() ? (typed === real.trim() ? 'success' : 'fail') : 'none';
            });
            
            this.originalLines = [...verifyRows];
            this.editor.innerText = verifyRows.join('\n');
            this.refreshUI(); 
            this.updateStatus('synced');

            setTimeout(() => { this.syncResults = []; this.refreshUI(); }, 3000);
        } catch (e) { 
            this.updateStatus('error'); 
        } finally { 
            this.isBusy = false; 
            vllink.isBusy = false; 
            this.lockUI(false); 
        }
    },

    lockUI(locked) {
        document.body.classList.toggle('pointer-events-none', locked);
        this.container.classList.toggle('opacity-50', locked);
    }
};

/**
 * 核心逻辑集成与状态机 (包含强制手动选择与无感重连)
 */
const vllink = new VllinkManager();
let pollTimer = null;
let lastFingerprint = "";
let lastDeviceCache = null;
let lastInfo = null;

// 【新特性】：记录用户是否手动断开的临时标志位
let forceManualSelection = false; 

const UI = {
    connectBtn: document.getElementById('connectBtn'),
    deviceList: document.getElementById('deviceList'),
    status: document.getElementById('connectionStatus')
};

// 提取的连接核心流程
async function performConnection(autoDevice = null, forceRequest = false) {
    await vllink.connect(autoDevice, forceRequest);
    
    // 缓存设备特征以备自动重连
    lastDeviceCache = {
        vid: vllink.device.vendorId,
        pid: vllink.device.productId,
        sn: vllink.device.serialNumber
    };

    ConfigEditor.lastSelectedIdx = -1;
    ConfigEditor.originalLines = [];
    DataManager.activeBuffers = {};
    vllink.isBusy = false;
    lastFingerprint = "";

    // 探测目标电源跌落能力（DAP_PowerCycle 0x0F）与当前状态
    vllink.powerCapable = await vllink.queryPowerCapability();
    vllink.powerState = vllink.powerCapable ? await vllink.queryPowerState() : null;

    UI.status.innerText = "ONLINE: " + vllink.device.productName;
    UI.connectBtn.innerText = "Disconnect";
    UI.connectBtn.classList.remove('bg-primary', 'bg-rose-500');
    UI.connectBtn.classList.add('bg-green-600');
    
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(async () => {
        try {
            const info = await vllink.queryInfo();
            if (!info) return;
            updateDisplay(info);

            // 低频同步电源状态（避免每 250ms 都占用 DAP 通道）
            if (vllink.powerCapable && !vllink.isBusy &&
                (Date.now() - (vllink._powerStamp || 0) > 1500)) {
                vllink._powerStamp = Date.now();
                const st = await vllink.queryPowerState();
                if (st) { vllink.powerState = st; refreshPowerButtons(info); }
            }
            
            if (info.select_idx !== ConfigEditor.lastSelectedIdx) {
                ConfigEditor.lastSelectedIdx = info.select_idx;
                ConfigEditor.load(vllink);
                if (!TabManager.contents.data.classList.contains('hidden')) DataManager.load();
            }
        } catch (e) {
            if (e.message.includes('disconnected') || e.name === 'NetworkError' || e.name === 'NotFoundError') {
                handleDeviceDisconnect(false); // 物理断开，不触发手动标志
            }
        }
    }, 250);
}

// 统一的断开处理
async function handleDeviceDisconnect(manual = false) {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
    
    if (manual) {
        if (typeof vllink.disconnect === 'function') await vllink.disconnect();
        // 如果是手动断开，打上临时强制标志
        forceManualSelection = true;
    } else {
        // 如果是线缆被意外拔出，不认为是主动想换设备，下次插上允许自动直连
        forceManualSelection = false;
    }

    UI.status.innerText = "OFFLINE";
    UI.connectBtn.innerText = "Connect Vllink";
    UI.connectBtn.classList.remove('bg-green-600', 'bg-rose-500');
    UI.connectBtn.classList.add('bg-primary');
    UI.deviceList.innerHTML = `<div class="text-center py-10 text-slate-500 text-xs italic">Waiting for connection...</div>`;
    lastFingerprint = "";

    ConfigEditor.lastSelectedIdx = -1;
    ConfigEditor.originalLines = [];
    if (ConfigEditor.editor) ConfigEditor.editor.innerText = "";
    ConfigEditor.updateStatus('error');
    ConfigEditor.lockUI(false);
    ConfigEditor.container.innerHTML = `<div class="glass border border-slate-200 dark:border-slate-800 rounded-3xl p-20 flex flex-col items-center justify-center italic text-slate-500"><span class="text-4xl mb-4">🔌</span>Device disconnected...</div>`;
    
    DataManager.activeBuffers = {};
    DataManager.container.innerHTML = `<div class="glass border border-slate-200 dark:border-slate-800 rounded-3xl p-20 flex flex-col items-center justify-center italic text-slate-500"><span class="text-4xl mb-4">🔌</span>Device disconnected...</div>`;
    
    vllink.isBusy = false;
    vllink.device = null;
    vllink.powerCapable = false;
    vllink.powerState = null;
    lastInfo = null;
}

// ==========================================
// 网页启动时的“静默自动重连”
// ==========================================
async function autoConnectOnLoad() {
    if (!navigator.usb) return;
    try {
        const authorizedDevices = await navigator.usb.getDevices();
        const matchedDevices = authorizedDevices.filter(d => 
            vllink.filters.some(f => f.vendorId === d.vendorId && f.productId === d.productId)
        );

        if (matchedDevices.length > 0) {
            // 【新特性】：寻找 SN 匹配的最近连接设备
            const lastSn = localStorage.getItem('vllink-last-sn');
            let target = matchedDevices.find(d => d.serialNumber && d.serialNumber === lastSn);
            if (!target) target = matchedDevices[0]; // fallback

            UI.status.innerText = "AUTO CONNECTING...";
            await performConnection(target);
        }
    } catch (e) {
        console.warn("Auto connect on load failed:", e);
    }
}

// 原生监听：中途拔插的静默拉起重连
navigator.usb.addEventListener('connect', async (event) => {
    const dev = event.device;
    if (!vllink.device && lastDeviceCache && 
        dev.vendorId === lastDeviceCache.vid && 
        dev.productId === lastDeviceCache.pid && 
        dev.serialNumber === lastDeviceCache.sn) {
        try {
            UI.status.innerText = "AUTO CONNECTING...";
            await performConnection(dev);
        } catch (e) {
            handleDeviceDisconnect(false);
        }
    }
});

navigator.usb.addEventListener('disconnect', (event) => {
    if (vllink.device && event.device === vllink.device) {
        handleDeviceDisconnect(false);
    }
});

// 手动点击大按钮
UI.connectBtn.addEventListener('click', async () => {
    // 已经连接时，点击即为主动断开 -> 设置标记
    if (vllink.device) {
        await handleDeviceDisconnect(true);
        return;
    }
    
    // 执行连接。如果 forceManualSelection 为 true，系统会强制弹出原生框。
    try {
        await performConnection(null, forceManualSelection);
        // 连接成功后，清除该临时强制标记
        forceManualSelection = false;
    } catch (e) {
        // 用户可能在原生弹窗里点了“取消”，保留标记以供下次继续选
        console.warn("Connect aborted or error: " + e.message);
    }
});

UI.connectBtn.addEventListener('mouseenter', () => {
    if(vllink.device) UI.connectBtn.classList.replace('bg-green-600', 'bg-rose-500');
});
UI.connectBtn.addEventListener('mouseleave', () => {
    if(vllink.device) UI.connectBtn.classList.replace('bg-rose-500', 'bg-green-600');
});

// 列表点击切换或重启
UI.deviceList.addEventListener('click', async (e) => {
    const powerBtn = e.target.closest('.power-btn');
    if (powerBtn) {
        e.stopPropagation();
        if (powerBtn.disabled) return;
        const card = powerBtn.closest('[data-id]');
        if (!card || Number(card.dataset.id) !== lastInfo?.select_idx) return;

        const bit = Number(powerBtn.dataset.ch);
        const down = powerBtn.dataset.down === '1';
        powerBtn.disabled = true;
        vllink.isBusy = true;
        try {
            const st = await vllink.setPowerDown(bit, !down);
            if (st) {
                vllink.powerState = st;
                if (lastInfo) refreshPowerButtons(lastInfo);
            }
        } catch (err) {
            console.warn("Power control failed:", err);
        } finally {
            vllink.isBusy = false;
            powerBtn.disabled = false;
        }
        return;
    }

    const restartBtn = e.target.closest('.restart-btn');
    if (restartBtn) {
        e.stopPropagation();
        const card = restartBtn.closest('[data-id]');
        if (confirm(`Restart Node ${card.dataset.id}?`)) {
            try { await vllink.resetDevice(); location.reload(); } catch (err) { }
        }
        return;
    }
    const card = e.target.closest('[data-id]');
    if (card) vllink.selectDebugger(parseInt(card.dataset.id));
});

function updateDisplay(info) {
    lastInfo = info;
    const all = [{ ...info.local, id: 0, type: 'USB' }];
    info.remote.forEach(r => all.push({ ...r, type: 'WIFI' }));
    
    const fingerprint = all.map(d => `${d.id}-${d.mac}`).join('|');
    if (fingerprint !== lastFingerprint) {
        UI.deviceList.innerHTML = all.map(dev => `
            <div data-id="${dev.id}" class="device-card p-5 rounded-2xl cursor-pointer opacity-80 hover:opacity-100 flex flex-col gap-3 relative group">
                <div class="flex justify-between items-center">
                    <span class="text-sm font-black text-slate-800 dark:text-slate-50 truncate uppercase pr-6">${dev.alias}</span>
                    <div class="flex items-center gap-2">
                        <button class="restart-btn opacity-0 group-hover:opacity-100 p-1 hover:bg-red-500/20 rounded text-red-500 transition-all" title="Restart">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                        </button>
                        <span class="text-[10px] bg-slate-300/50 dark:bg-white/10 px-2 py-1 rounded font-black">${dev.type}</span>
                    </div>
                </div>
                <div class="flex items-center gap-2 font-mono text-xs text-slate-500">
                    <span class="uppercase tracking-tighter">Addr</span><span class="text-slate-600 dark:text-slate-300">${dev.mac}</span>
                </div>
                <div class="grid grid-cols-2 gap-2 mt-1">
                    <div class="flex flex-col"><span class="text-[9px] text-slate-400 uppercase font-black">Uptime</span><span class="uptime-val font-mono text-sm font-bold text-slate-700 dark:text-slate-200">00:00:00</span></div>
                    <div class="flex flex-col items-end"><span class="text-[9px] text-slate-400 uppercase font-black">Latency</span><span class="delay-val font-mono text-sm text-primary font-black">-</span></div>
                </div>
                <div class="power-row hidden items-center gap-2 pt-1 border-t border-slate-200/60 dark:border-white/10">
                    <span class="text-[9px] text-slate-400 uppercase font-black tracking-wider">跌落</span>
                    <button class="power-btn" data-ch="1" title="VREF 跌落/恢复">VREF</button>
                    <button class="power-btn" data-ch="2" title="VOUT 5V 跌落/恢复">VOUT</button>
                </div>
            </div>`).join('');
        lastFingerprint = fingerprint;
    }
    
    all.forEach(dev => {
        const card = UI.deviceList.querySelector(`[data-id="${dev.id}"]`);
        if (!card) return;
        card.classList.toggle('card-active', info.select_idx === dev.id);
        const t = dev.id === 0 ? Number(info.local.us)/1e6 : Number(info.local.us - dev.us)/1e6;
        card.querySelector('.uptime-val').innerText = formatTime(t);
        card.querySelector('.delay-val').innerText = dev.delay_us > 0 ? `${dev.delay_us} us` : "-";
    });

    refreshPowerButtons(info);
}

/**
 * 刷新设备卡片上的电源跌落按钮（仅当前选中节点 + 支持 0x0F + 通道已配置时显示）
 */
function refreshPowerButtons(info) {
    const st = vllink.powerState;
    UI.deviceList.querySelectorAll('.device-card').forEach(card => {
        const isSelected = Number(card.dataset.id) === info.select_idx;
        const row = card.querySelector('.power-row');
        if (!row) return;

        const show = isSelected && vllink.powerCapable && st;
        row.classList.toggle('hidden', !show);
        if (show) { row.classList.add('flex'); } else { row.classList.remove('flex'); }
        if (!show) return;

        row.querySelectorAll('.power-btn').forEach(btn => {
            const bit = Number(btn.dataset.ch);
            const name = bit === 1 ? 'VREF' : 'VOUT';
            const configured = (st.config & bit) !== 0;
            const powered = (st.power & bit) !== 0;
            const down = configured && !powered;

            btn.disabled = !configured;
            btn.dataset.down = down ? '1' : '0';

            if (!configured) {
                /* 通道未配置：锁定为红色关闭态 */
                btn.innerText = `${name} ✕`;
                btn.title = `${name} 未配置（已在配置中关闭）`;
                btn.className = 'power-btn text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded-md border transition-all ' +
                    'border-rose-500/30 text-rose-500/60 bg-rose-500/5 cursor-not-allowed opacity-70';
            } else if (down) {
                btn.innerText = `${name} ↓`;
                btn.title = `${name} 已跌落（点击恢复）`;
                btn.className = 'power-btn text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded-md border transition-all active:scale-95 ' +
                    'border-rose-500/50 text-rose-500 bg-rose-500/10 hover:bg-rose-500/20';
            } else {
                btn.innerText = `${name} ↑`;
                btn.title = `${name} 正常输出（点击跌落）`;
                btn.className = 'power-btn text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded-md border transition-all active:scale-95 ' +
                    'border-emerald-500/50 text-emerald-500 bg-emerald-500/10 hover:bg-emerald-500/20';
            }
        });
    });
}

function formatTime(s) {
    const t = Math.max(0, s);
    const h = Math.floor(t / 3600).toString().padStart(2, '0');
    const m = Math.floor((t % 3600) / 60).toString().padStart(2, '0');
    const sec = Math.floor(t % 60).toString().padStart(2, '0');
    return `${h}:${m}:${sec}`;
}

// 全局初始化
ThemeManager.init();
TabManager.init();
ConfigEditor.init();

// 执行开屏自动免打扰重连
autoConnectOnLoad();