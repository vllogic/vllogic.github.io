#!/usr/bin/env python3
"""
VLLINK Hercules 下载器

  python3 hercules_dl.py info
  python3 hercules_dl.py chip  <file>
  python3 hercules_dl.py flash <file> [--autorun] [--no-verify]

flash: erase 必开, verify 默认开, autorun 默认关
auto cut acf: 仅对 .acf 生效, 跳过开头 "//" 注释行

适用硬件: VLLINK Basic2 / VLLINK 2X / VLLINK HME
前提条件:
  - 必须已接好 FPGA 目标板
  - 不得通过 VLLINK 给 FPGA 供电 (当前固件限制), 目标板需独立供电
"""
import argparse, struct, sys, time
import usb.core, usb.util

VID, PID = 0x1209, 0x6666
SUB_INFO, SUB_PROBE, SUB_CHIP_WRITE, SUB_FLASH_WRITE = 0x00, 0x10, 0x20, 0x30
OP_ERASE, OP_WRITE, OP_VERIFY, OP_WRITEQUICK, OP_AUTORESET = 0x2, 0x4, 0x8, 0x10, 0x40
CHUNK = 256                     # 固件要求 data_len 为 4 的倍数且 <= 256
MIN_RESP = {SUB_INFO: 12, SUB_PROBE: 16, SUB_CHIP_WRITE: 8, SUB_FLASH_WRITE: 8}

TARGETS = {0: "M5", 1: "M7", 2: "HR02", 3: "HR03", 4: "P1", 5: "H1D03",
           6: "H1C02", 7: "H3", 8: "P0", 9: "P2", 10: "P3", 11: "H3P", 12: "EX1"}
CHIP_SKIP = {4: 8, 5: 8, 6: 72, 7: 72, 8: 72, 9: 72, 10: 72, 11: 72, 12: 72}


def cut_acf(data):
    pos = 0
    while pos + 1 < len(data) and data[pos:pos + 2] == b"//":
        nl = data.find(b"\n", pos)
        if nl < 0:
            return len(data)
        pos = nl + 1
    return pos


class Hercules:
    def __init__(self):
        dev = usb.core.find(idVendor=VID, idProduct=PID)
        if dev is None:
            sys.exit("未找到 VLLINK 设备")
        self.dev = dev
        self.common = b"\x00" * 12
        try:
            usb.util.claim_interface(dev, 0)
        except usb.core.USBError as e:
            sys.exit("错误: USB 接口被占用 (%s)；请关闭浏览器调试页或调试器软件" % e)
        for _ in range(8):
            try:
                dev.read(0x81, 512, timeout=30)
            except Exception:
                break

    def xfer(self, pkt, timeout=30000):
        self.dev.write(0x01, bytes(pkt), timeout=3000)
        r = bytes(self.dev.read(0x81, 512, timeout=timeout))
        if len(r) < MIN_RESP.get(pkt[1], 4) or r[0] != 0x90 or r[1] != pkt[1]:
            raise RuntimeError("响应异常: %s" % r[:16].hex())
        return r

    def info(self):
        return struct.unpack_from("<II", self.xfer([0x90, SUB_INFO]), 4)

    def probe(self, supported):
        r = self.xfer([0x90, SUB_PROBE])
        attach, khz, ttype, devnum, cap = struct.unpack_from("<IHBBI", r, 4)
        if r[3] != 0 or not khz or ttype >= supported:
            raise RuntimeError("目标未 attach 或不受支持 "
                               "(type=%d, khz=%d, sts=%d)" % (ttype, khz, r[3]))
        self.common = bytes(r[4:16])
        return dict(attach=attach, khz=khz, ttype=ttype,
                    devnum=devnum, capacity=cap)

    def write(self, sub, data, op, addr=None, window=4):
        total, pos = len(data), 0
        t0 = tprint = time.time()
        window = max(1, window)
        while pos < total:
            batch = []
            while len(batch) < window and pos < total:
                ln = min(CHUNK, total - pos)
                batch.append((pos, ln))
                pos += ln
            for p, ln in batch:
                hdr = (struct.pack("<IIII", op, total, p, ln) if addr is None else
                       struct.pack("<IIIII", op, total, addr, p, ln))
                self.dev.write(0x01, bytes([0x90, sub]) + self.common + hdr +
                               data[p:p + ln], timeout=3000)
            for p, ln in batch:
                r = bytes(self.dev.read(0x81, 512, timeout=30000))
                if len(r) < MIN_RESP.get(sub, 8) or r[0] != 0x90 or r[1] != sub:
                    raise RuntimeError("响应异常: %s" % r[:16].hex())
                if r[3] != 0:
                    raise RuntimeError("写入失败 @%d, subSts=%d" % (p, r[3]))
                got = struct.unpack_from("<I", r, 4)[0]
                if not 0 < got <= ln:
                    raise RuntimeError("响应长度异常 @%d: %d" % (p, got))
            now = time.time()
            if pos >= total or now - tprint >= 1.0:
                print("  %6d / %6d  %3d%%  %.1fs" %
                      (pos, total, pos * 100 // total, now - t0), flush=True)
                tprint = now

    def close(self):
        try:
            usb.util.release_interface(self.dev, 0)
            usb.util.dispose_resources(self.dev)
        except Exception:
            pass


def main():
    ap = argparse.ArgumentParser(description="VLLINK Hercules download tool")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("info", help="只读探测 (不擦除不写入)")
    p_chip = sub.add_parser("chip", help="Chip Download")
    p_chip.add_argument("file")
    p_chip.add_argument("--window", type=int, default=4, help="批量提交窗口 (默认 4, 1=同步)")
    p_flash = sub.add_parser("flash", help="Flash Download")
    p_flash.add_argument("file")
    p_flash.add_argument("--autorun", action="store_true", help="写完后让目标运行 (默认关)")
    p_flash.add_argument("--no-verify", action="store_true", help="关闭边写边校验 (默认开)")
    p_flash.add_argument("--window", type=int, default=4, help="批量提交窗口 (默认 4, 1=同步)")
    a = ap.parse_args()
    t_start = time.time()

    if a.cmd == "info":
        raw, cut = b"", 0
    else:
        try:
            raw = open(a.file, "rb").read()
        except OSError as e:
            sys.exit("错误: %s" % e)
        if not raw:
            sys.exit("错误: 镜像为空 (%s)" % a.file)
        cut = cut_acf(raw) if a.file.lower().endswith(".acf") else 0
        if a.cmd == "flash":
            n = len(raw) - cut
            if not n:
                sys.exit("错误: 裁剪后无数据可写")
            if n % 4:
                sys.exit("错误: 长度 %d 不是 4 的倍数, 固件会拒绝最后一块" % n)

    dap = Hercules()
    try:
        version, supported = dap.info()
        print("DAP 版本: %s  支持器件数: %d" % (hex(version), supported))

        info = dap.probe(supported)
        print("目标: %s  JTAG 时钟: %d kHz  Flash: %d KB  类型号: %d  器件数: %d" %
              (TARGETS.get(info["ttype"], "Unknown"), info["khz"],
               info["capacity"] // 1024, info["ttype"], info["devnum"]))
        if a.cmd == "info":
            print("耗时: %.2fs" % (time.time() - t_start))
            return

        start = cut if a.cmd == "flash" else cut + CHIP_SKIP.get(info["ttype"], 0)
        data = raw[start:]
        if not data:
            sys.exit("错误: 裁剪后无数据可写")
        if len(data) % 4:
            sys.exit("错误: 长度 %d 不是 4 的倍数, 固件会拒绝最后一块" % len(data))
        if info["capacity"] and len(data) > info["capacity"]:
            sys.exit("错误: 镜像 %d B 超过 Flash 容量 %d B" %
                     (len(data), info["capacity"]))

        if a.cmd == "chip":
            op = OP_WRITE | OP_WRITEQUICK
            print("Chip Download: %d -> %d bytes (跳过 %d), op=0x%x" %
                  (len(raw), len(data), start, op))
            dap.write(SUB_CHIP_WRITE, data, op, window=a.window)
            print("Chip Download 完成, %d bytes, 耗时 %.2fs" %
                  (len(data), time.time() - t_start))
        else:
            op = OP_WRITE | OP_ERASE
            if not a.no_verify:
                op |= OP_VERIFY
            if a.autorun:
                op |= OP_AUTORESET
            print("Flash Download: %d -> %d bytes (跳过 %d), op=0x%x "
                  "[erase=on verify=%s autorun=%s]" %
                  (len(raw), len(data), start, op,
                   "off" if a.no_verify else "on", "on" if a.autorun else "off"))
            dap.write(SUB_FLASH_WRITE, data, op, addr=0, window=a.window)
            print("Flash Download 完成, %d bytes, 耗时 %.2fs" %
                  (len(data), time.time() - t_start))
    except (RuntimeError, usb.core.USBError, OSError) as e:
        print("错误: %s" % e)
        sys.exit(1)
    finally:
        dap.close()


if __name__ == "__main__":
    main()
