---
name: VLLINK Hercules Flash 下载
description: 用 VLLINK Basic2 / 2X / HME 调试器通过 Hercules vendor 协议（0x90 子命令）直接给 HME/Hercules 系列 FPGA 下载 Flash 或 Chip，支持 erase/verify/autorun 与 .acf 注释裁剪。当需要给 H1C02、H1D03、H3、P1、P0/P2/P3、M5/M7、EX1 目标板烧录 .bin/.acf、做只读探测、或排查下载失败（probe 失败、subSts 异常）时使用。目标板必须独立供电，不得由 VLLINK 供电。
---

# VLLINK Hercules Flash 下载

PC 侧不构建 JTAG 序列：上位机只发语义命令（子命令 + 12 字节器件头 + 参数 + 数据块，参数 flash 20 字节 / chip 16 字节），调试器固件自行展开时序。

## 何时使用

- 给 HME/Hercules 目标板烧录 Flash 镜像（`.bin` / `.acf`）
- 只读确认目标型号、时钟、容量，不写入
- 需要批量、可脚本化的烧录或烧录自检
- 下载报错需要定位（probe 失败、`subSts` 非 0、设备被占用）

不适用：通用 JTAG 调试、读寄存器、断点追踪（走标准 CMSIS-DAP 通道）。

## 前置条件

- 硬件：**VLLINK Basic2 / VLLINK 2X / VLLINK HME**（USB `1209:6666`）
- 必须已接好 FPGA 目标板
- **不得通过 VLLINK 给 FPGA 供电**（当前固件限制：检测到 FPGA 类负载会切断输出），目标板必须独立供电，VREF 需接好
- 主机需要 `pyusb`，并且当前用户有该 USB 设备的访问权限

```bash
python3 -c "import usb.core; print(usb.core.find(idVendor=0x1209, idProduct=0x6666))"
```

权限不足时添加 udev 规则（示例）：

```text
SUBSYSTEM=="usb", ATTR{idVendor}=="1209", ATTR{idProduct}=="6666", MODE="0666", GROUP="plugdev"
```

同一时刻只能有一个进程占用设备；浏览器页面或调试器软件打开时会报占用。

## 用法

以下命令需在 skill 目录执行，或把 `scripts/hercules_dl.py` 换成绝对路径：

```bash
cd ~/.config/opencode/skills/vllink-hercules-download
python3 scripts/hercules_dl.py info
python3 scripts/hercules_dl.py chip  <file>
python3 scripts/hercules_dl.py flash <file> [--autorun] [--no-verify]
```

| 参数 | 说明 |
| --- | --- |
| `info` | 只读探测：DAP 版本、目标型号、时钟、容量、类型号；不擦除不写入 |
| `chip` | Chip Download，`op_mask = WRITE\|WRITEQUICK` |
| `flash` | Flash Download，`erase` 固定开启 |
| `--autorun` | 写入完成后让目标运行（`AUTORESET`），默认关 |
| `--no-verify` | 关闭边写边校验（`VERIFY`），默认开 |
| `--window` | 批量提交窗口，默认 4（连续发 4 包再收 4 个响应）；`1` 为同步逐包；实测 8 以上会退化，16 超时 |

`.acf` 文件会自动跳过开头的 `//` 注释行；`chip` 还会按目标类型跳过固定头部（H1D03/P1 跳 8，H1C02/H3/P0/P2/P3/H3P/EX1 跳 72）。

进度每秒输出一行，100% 必定输出。

三条命令都会打印 **JTAG 时钟**；`info` 和写入命令结束时打印 **总耗时**（含连接与 probe）。进度行里的秒数是写入阶段耗时，完成行的是总耗时，用于估算等待时间：

| 场景 | 参考耗时（随机数据） |
| --- | --- |
| `info` | 约 0.1–0.3s |
| ≤1KB flash（含连接与 probe） | 约 0.5s |
| 64KB flash | 约 0.9s |
| 512KB flash（`--window 4`，默认 verify） | 约 4.5s |
| 512KB flash（`--window 1`） | 约 5.5s |

窗口 4 相比逐包同步约快 20%；全 0xFF 镜像会因跳过实际编程而明显偏快，不能作为性能基线。

退出码：`0` 成功，`1` 运行失败（文件、设备或校验错误），`2` 参数错误。

## 协议要点

- 请求：`[0x90, 子命令, common(12B), 参数, 数据]`，参数 flash 为 20 字节（op/length/addr/pos/len），chip 为 16 字节（无 addr）
- 子命令：`0x00` GET_INFO、`0x10` PROBE、`0x20` CHIP_WRITE、`0x30` FLASH_WRITE
- `common` 来自 PROBE 响应，包含时间戳、时钟、器件类型、容量；**每条命令前必须先 probe，probe 成功才允许下载**
- 响应：`[0x90, 子命令, cmdSts, subSts, payload...]`，写入成功时 payload 前 4 字节是本次已处理的字节数
- `op_mask`：`0x01` READ、`0x02` ERASE、`0x04` WRITE、`0x08` VERIFY、`0x10` WRITEQUICK、`0x40` AUTORESET

## 固件限制

- 单次 `data_len` 必须是 **4 的倍数且不超过 256**
- 非 4 倍数 → `subSts=5`（FAIL）；超过 256 → `subSts=4`（VERIFY_FAIL）
- 因此镜像长度必须是 4 的倍数；否则最后一块失败，且此前已擦除并部分写入
- 脚本在连接设备前检查空文件和 4 字节对齐，probe 后检查容量，不满足直接退出且不擦除
- `probe` 会暂停器件；不带 `AUTORESET` 下载后器件可能停在暂停态，需要重新上电或改用 `--autorun`

## 错误排查

| 现象 | 原因 |
| --- | --- |
| `subSts=2` | common 头不匹配（时间戳过期），重新执行 `info` 后再试 |
| `subSts=3` | 头部非法 / 目标类型不受支持 |
| `subSts=4` | 校验失败（长度超限或数据不一致） |
| `subSts=5` | 写入失败（常见：长度不是 4 的倍数） |
| `目标未 attach 或不受支持 (type=255, khz=1000, sts=0)` | 器件未识别：检查目标是否独立供电、VREF、JTAG 接线 |
| `错误: USB 接口被占用 (...)；请关闭浏览器调试页或调试器软件` | 设备被其他进程占用 |
| `错误: 镜像为空` | 文件 0 字节，未接触硬件 |
| `错误: 长度 N 不是 4 的倍数` | 补齐到 4 字节边界，未擦除 |
| `错误: 镜像 N B 超过 Flash 容量 M B` | 换小镜像，未擦除 |
| `响应异常: ff` | 调试器通道异常，拔插 USB 恢复 |

## 烧录结果判断

`flash` 默认带 `OP_VERIFY`，命令返回 `subSts=0` 且进度到 100% 即表示写入并校验通过。脚本不提供读回功能；需要逐字节复核时，另行用 `0x90/0x31` 读命令。

## 安全提示

- `flash` 会擦除目标 Flash，执行前确认文件、目标和供电状态
- 不要对未知目标类型发送下载命令
- 烧录过程中不要拔线；失败后先用 `info` 确认目标仍在线，再重试
